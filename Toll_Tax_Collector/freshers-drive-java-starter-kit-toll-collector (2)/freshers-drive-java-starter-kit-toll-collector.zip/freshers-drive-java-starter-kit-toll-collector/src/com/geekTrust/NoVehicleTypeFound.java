package com.geekTrust;

public class NoVehicleTypeFound extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoVehicleTypeFound() {
		// TODO Auto-generated constructor stub
	}

	public NoVehicleTypeFound(String message) {
		super(message);
	}

}
